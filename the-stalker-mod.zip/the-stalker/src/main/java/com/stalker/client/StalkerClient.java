package com.stalker.client;

import com.stalker.StalkerMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class StalkerClient implements ClientModInitializer {
    public static final EntityModelLayer MODEL_LAYER =
            new EntityModelLayer(new Identifier(StalkerMod.MOD_ID, "stalker"), "main");

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(MODEL_LAYER, StalkerModel::getTexturedModelData);
        EntityRendererRegistry.register(StalkerMod.STALKER, StalkerRenderer::new);
    }
}
