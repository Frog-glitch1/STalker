# The Stalker (Fabric, Minecraft Java 1.20.1)

A psychological / liminal horror mod. Something tall, pale and silent has noticed you.

## Build
1. Install JDK 17.
2. This project has no Gradle wrapper. Either copy `gradlew`, `gradlew.bat` and the `gradle/` folder from the
   Fabric example mod, or run `gradle wrapper --gradle-version 8.5` once.
3. `./gradlew build` -> jar in `build/libs/`. Drop it in `mods/` with Fabric API 0.92.2+1.20.1.
   (`./gradlew runClient` launches a dev client.)

## How it works
Each player has a hidden **dread** meter. It rises while you are underground, in the dark, or out at night,
and falls in bright daylight, while sleeping, or when other players are within 24 blocks.

| Stage | Behaviour |
|-------|-----------|
| 0 Sighting | Stands 30-50 blocks away in plain sight. Stare at it for ~3s and it vanishes. |
| 1 Stalking | Follows at 14-24 blocks, ducks behind cover whenever you look at it. |
| 2 Hunting  | Freezes while watched, creeps closer when you look away, lunges if it reaches you. Stare it down ~10s and it retreats. Snuffs torches, pulses darkness, heartbeat. |
| 3 The Kill | Drops to all fours and chases at ~sprint speed for 100s. Bright light slows it. Survive, wound it (<30% HP) or kill it (80 HP) and it backs off, then returns later. |

From stage 1 on you also hear things that aren't there: doors, chests, footsteps, a creeper hiss, always behind you.

## Test commands (op)
- `/stalker summon`    spawn it near you now
- `/stalker stage <0-3>` jump to a stage
- `/stalker reset`

Tune thresholds, hunt length and speed in `StalkerConfig.java`.
Regenerate the textures with `python3 tools/make_textures.py` (needs Pillow).

## Notes
- It does not spawn in Peaceful (hostile mobs are removed there). Creative players are valid targets but take no damage.
- The Stalker and dread are not saved: restarting the world resets the stalking.
